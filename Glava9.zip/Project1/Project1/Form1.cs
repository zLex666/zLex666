﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace Project1
{
    public partial class Form1 : Form
    {
        protected Process[] procs;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string appPath = Application.ExecutablePath;
            MessageBox.Show(appPath);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show(System.AppDomain.CurrentDomain.BaseDirectory);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // создаем новый процесс
            Process proc = new Process();
            // Запускаем Блокнот
            proc.StartInfo.FileName = @"Notepad.exe";
            proc.StartInfo.Arguments = "";
            proc.Start();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            // Запускаем Блокнот с файлом test.txt
            Process.Start("notepad.exe", "test.txt");
        }

        private void button5_Click(object sender, EventArgs e)
        {
            // Запускаем браузер с заданным адресом
            Process.Start("iexplore.exe", "netsources.narod.ru");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // Устанавливаем информацию
            ProcessStartInfo start_info = new ProcessStartInfo
            (@"C:\windows\system32\notepad.exe");
            start_info.UseShellExecute = false;
            start_info.CreateNoWindow = true;
            // создаем новый процесс
            Process proc = new Process();
            proc.StartInfo = start_info;
            // Запускаем процесс
            proc.Start();
            // Ждем, пока Блокнот запущен
            proc.WaitForExit();
            MessageBox.Show("Код завершения: " + proc.ExitCode, "Завершение " +
            "Код", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button9_Click(object sender, EventArgs e)
        {
            procs = Process.GetProcessesByName("Notepad");
            int i = 0;
            while (i != procs.Length)
            {
                procs[i].Kill();
                i++;
                MessageBox.Show("Всего : " + i.ToString());
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            int am = Process.GetCurrentProcess().ProcessorAffinity.ToInt32();
            int processorCount = 0;
            while (am != 0)
            {
                processorCount++;
                am &= (am - 1);
            }
            MessageBox.Show(processorCount.ToString());
        }

        private void button10_Click(object sender, EventArgs e)
        {
            // Делаем паузу на 3 секунды
            System.Threading.Thread.Sleep(3000);
        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            foreach (Process p in Process.GetProcesses())
                listBox1.Items.Add(p.ToString());
        }

        private void button12_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            foreach (Process p in
            Process.GetProcesses(System.Environment.MachineName))
            {
                if (p.MainWindowHandle != IntPtr.Zero)
                {
                    // Оконные приложения
                    listBox1.Items.Add(p.ToString());
                }
            }
        }

        private void button13_Click(object sender, EventArgs e)
        {
            // Очистим список
            listBox1.Items.Clear();
            // Получим список процессов, связанных с Internet Explorer
            foreach (Process p in Process.GetProcessesByName("iexplore"))
                listBox1.Items.Add(p.ToString());
        }

        private void button14_Click(object sender, EventArgs e)
        {
            // Очистим список
            listBox1.Items.Clear();
            // Получим список процессов notepad на удаленной машине skynet
            foreach (Process p in Process.GetProcessesByName("notepad","skynet"))
                listBox1.Items.Add(p.ToString());
        }

        private void button8_Click_1(object sender, EventArgs e)
        {
            
        }
    }

       
}
